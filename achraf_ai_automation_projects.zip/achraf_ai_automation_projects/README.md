# n8n Workflows + VAPI Voice Agents

Production-style automation portfolio for CRM, payments, reporting, alert routing, AI lead qualification and voice-agent appointment booking.

Built for a GitHub portfolio: every project includes a clean README, an importable `workflow.json`, and a visual preview.

## Projects

| # | Project | Main value |
|---|---|---|
| 01 | Lead Capture Automation | Form leads → CRM + Sheets + Slack |
| 02 | E-commerce Order Handler | Order webhook → loyalty tier → personalized email |
| 03 | Weekly Business Report | Scheduled APIs → formatted email report |
| 04 | Team Notification Hub | One webhook → route alerts to the right team |
| 05 | AI Lead Qualifier | GPT lead scoring → Hot/Warm/Cold routing |
| 06 | Clinic Voice Agent | VAPI voice receptionist → appointment booking |

## How to use

1. Open the project folder you want.
2. Import `workflow.json` into n8n.
3. Connect your credentials inside n8n.
4. Replace placeholder IDs, emails, sheet IDs, API keys and webhook URLs.
5. Test with the sample payloads in each README.

## Safe to publish

No live passwords or private API keys are included. All credentials are placeholders and should be configured inside n8n/VAPI.

## Author

Achraf Karzit — AI Automation / Sales Ops / CRM Workflows
